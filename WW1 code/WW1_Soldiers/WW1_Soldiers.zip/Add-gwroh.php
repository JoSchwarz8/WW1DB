<?php
require_once 'DBconnect.php';
require_once 'function.php'; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    add_GWROH();
    echo "Record added successfully";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Add to Database - Bradford and Surrounding Townships</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .form-section {
            background-color: #999;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            align-items: flex-start;
        }
        .form-section .input-group {
            display: flex;
            flex-direction: column;
            flex: 1 1 200px;
        }
        .form-section label {
            color: #9b111e;
            font-weight: bold;
            margin-bottom: 5px;
            font-size: 0.9rem;
        }
        .form-section input[type="text"],
        .form-section input[type="date"] {
            padding: 8px 12px;
            font-size: 0.9rem;
            border: 1px solid #ccc;
            border-radius: 4px;
            background-color: #fff;
        }
        .form-buttons {
            display: flex;
            gap: 10px;
            width: 100%;
            margin-top: 10px;
        }
        .table-container {
            margin-top: 20px;
            overflow-x: auto;
        }
        .table-container table {
            width: 100%;
            border-collapse: collapse;
        }
        .table-container th,
        .table-container td {
            border: 1px solid #ddd;
            padding: 6px 8px;
            font-size: 0.8rem;
            white-space: nowrap;
        }
        .table-container thead {
            background-color: #9b111e;
            color: #fff;
        }
    </style>
</head>
<body class="table-page">
<div class="container">
    <h1>Add to Database - Bradford and Surrounding Townships</h1>
    <form id="addRecordForm" class="form-section" action="gwroh.php" method="post">
        <!-- Surrounding Towns fields -->
        <div class="input-group">
            <label for="surname">Surname</label>
            <input type="text" id="surname" name="Surname" placeholder="Enter surname" required>
        </div>
        <div class="input-group">
            <label for="forename">Forename</label>
            <input type="text" id="forename" name="Forename" placeholder="Enter forename" required>
        </div>
        <div class="input-group">
            <label for="address">Address</label>
            <input type="text" id="address" name="Address" placeholder="Enter address">
        </div>
        <div class="input-group">
            <label for="electoralWard">Electoral Ward</label>
            <input type="text" id="electoralWard" name="Electoral Ward" placeholder="Enter electoral ward">
        </div>
        <div class="input-group">
            <label for="town">Town</label>
            <input type="text" id="town" name="Town" placeholder="Enter town">
        </div>
        <div class="input-group">
            <label for="rank">Rank</label>
            <input type="text" id="rank" name="Rank" placeholder="Enter rank">
        </div>
        <div class="input-group">
            <label for="regiment">Regiment</label>
            <input type="text" id="regiment" name="Regiment" placeholder="Enter regiment">
        </div>
        <div class="input-group">
            <label for="unit">Unit</label>
            <input type="text" id="unit" name="Battalion" placeholder="Enter unit">
        </div>
        <div class="input-group">
            <label for="company">Company</label>
            <input type="text" id="company" name="Company" placeholder="Enter company">
        </div>
        <div class="input-group">
            <label for="age">Age</label>
            <input type="text" id="age" name="DoB" placeholder="Enter age">
        </div>
        <div class="input-group">
            <label for="serviceNo">Service No</label>
            <input type="text" id="serviceNo" name="Service no" placeholder="Enter service number">
        </div>
        <div class="input-group">
            <label for="otherRegiment">Other Regiment</label>
            <input type="text" id="otherRegiment" name="Other Regiment" placeholder="Enter other regiment">
        </div>
        <div class="input-group">
            <label for="otherUnit">Other Unit</label>
            <input type="text" id="otherUnit" name="Other Unit" placeholder="Enter other unit">
        </div>
        <div class="input-group">
            <label for="otherServiceNo">Other Service No</label>
            <input type="text" id="otherServiceNo" name="Other Service no" placeholder="Enter other service number">
        </div>
        <div class="input-group">
            <label for="medals">Medals</label>
            <input type="text" id="medals" name="Medals" placeholder="Enter medals">
        </div>
        <div class="input-group">
            <label for="enlistmentDate">Enlistment Date</label>
            <input type="date" id="Enlistment Date" name="enlistmentDategwroh">
        </div>
        <div class="input-group">
            <label for="dischargeDate">Discharge Date</label>
            <input type="date" id="Discharge Date" name="dischargeDategwroh">
        </div>
        <div class="input-group">
            <label for="deathDate">Death Date</label>
            <input type="date" id="Death (in service) Date" name="deathDategwroh">
        </div>
        <div class="input-group">
            <label for="miscInfoNroh">Misc Info Nroh</label>
            <input type="text" id="Misc info (Norh)" name="miscInfogwroh" placeholder="Enter miscellaneous info">
        </div>
        <div class="input-group">
            <label for="cemeteryMemorial">Cemetery/Memorial</label>
            <input type="text" id="Cemetery/Memorial" name="cemeteryMemorialgwroh" placeholder="Enter cemetery/memorial">
        </div>
        <div class="input-group">
            <label for="cemeteryMemorialRef">Cemetery/Memorial Ref</label>
            <input type="text" id="Cemetery/Memorial Ref" name="cemeteryMemorialRefgwroh" placeholder="Enter cemetery/memorial ref">
        </div>
        <div class="input-group">
            <label for="cemeteryMemorialCountry">Cemetery/Memorial Country</label>
            <input type="text" id="Cemetery/Memorial Country" name="cemeteryMemorialCountrygwroh" placeholder="Enter cemetery/memorial country">
        </div>
        <div class="input-group">
            <label for="additionalCWGC">Additional CWGC info</label>
            <input type="text" id="Misc info (cwgc)" name="additionalCWGCgwroh" placeholder="Enter additional CWGC info">
        </div>
        <div class="form-buttons">
            <button type="submit" id="submitBtn" class="btn btn-primary">Add Record</button>
            <button type="reset" id="clearFormBtn">Clear Fields</button>
        </div>
    </form>
    <!-- Optional table to display records on the form page if needed -->
    <div class="table-container">
        <div class="table-wrapper">
            <table id="recordsTable">
                <thead>
                <tr>
                    <th>Surname</th>
                    <th>Forename</th>
                    <th>Address</th>
                    <th>Electoral Ward</th>
                    <th>Town</th>
                    <th>Rank</th>
                    <th>Regiment</th>
                    <th>Unit</th>
                    <th>Company</th>
                    <th>Age</th>
                    <th>Service No</th>
                    <th>Other Regiment</th>
                    <th>Other Unit</th>
                    <th>Other Service No</th>
                    <th>Medals</th>
                    <th>Enlistment Date</th>
                    <th>Discharge Date</th>
                    <th>Death Date</th>
                    <th>Misc Info Nroh</th>
                    <th>Cemetery/Memorial</th>
                    <th>Cemetery/Memorial Ref</th>
                    <th>Cemetery/Memorial Country</th>
                    <th>Additional CWGC info</th>
                </tr>
                </thead>
                <tbody>
                <!-- New rows will be added here if user chooses not to redirect -->
                </tbody>
            </table>
        </div>
    </div>
    <div class="bottom-section" style="margin-top:20px;">
        <a class="back-button" href="dashboard.html">Back</a>
    </div>
</div>
<script>
    document.getElementById('addRecordForm').addEventListener('submit', function(event) {
        
        const recordValues = {
            surname: document.getElementById('surname').value,
            forename: document.getElementById('forename').value,
            address: document.getElementById('address').value,
            electoralWard: document.getElementById('electoralWard').value,
            town: document.getElementById('town').value,
            rank: document.getElementById('rank').value,
            regiment: document.getElementById('regiment').value,
            unit: document.getElementById('unit').value,
            company: document.getElementById('company').value,
            age: document.getElementById('age').value,
            serviceNo: document.getElementById('serviceNo').value,
            otherRegiment: document.getElementById('otherRegiment').value,
            otherUnit: document.getElementById('otherUnit').value,
            otherServiceNo: document.getElementById('otherServiceNo').value,
            medals: document.getElementById('medals').value,
            enlistmentDate: document.getElementById('enlistmentDate').value,
            dischargeDate: document.getElementById('dischargeDate').value,
            deathDate: document.getElementById('deathDate').value,
            miscInfoNroh: document.getElementById('miscInfoNroh').value,
            cemeteryMemorial: document.getElementById('cemeteryMemorial').value,
            cemeteryMemorialRef: document.getElementById('cemeteryMemorialRef').value,
            cemeteryMemorialCountry: document.getElementById('cemeteryMemorialCountry').value,
            additionalCWGC: document.getElementById('additionalCWGC').value
        };
        const params = new URLSearchParams();
        params.set("newRecord", "1");
        for (const key in recordValues) {
            params.set(key, recordValues[key]);
        }
        if (confirm("Record added successfully. Would you like to view the updated Bradford and Surrounding Townships table?")) {
            window.location.href = "BradSurrTowns.html?" + params.toString();
        } else {
            alert("Record added successfully. You can continue adding records.");
            this.reset();
        }
    });
</script>
</body>
</html>
