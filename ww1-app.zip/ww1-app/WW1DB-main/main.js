const { app, BrowserWindow } = require('electron');
const path = require('path');

function createWindow () {
  const win = new BrowserWindow({
    width: 1920,
    height: 1080,
    fullscreen: true,
    kiosk: true,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
    }
  });

  // Use safe, cross-platform path
  win.loadFile(path.join(__dirname, 'ww1-app', 'WW1DB-main', 'WW1 code', 'HTML', 'dashboard.html'));

  win.setMenu(null);

  win.webContents.on('before-input-event', (event, input) => {
    if (input.key === 'F12' || input.control || input.alt || input.meta) {
      event.preventDefault();
    }
  });
}

app.whenReady().then(createWindow);
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
