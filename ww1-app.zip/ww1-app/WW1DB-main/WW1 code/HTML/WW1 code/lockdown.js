// lockdown.js

// 1. Fullscreen activation
function enableFullScreen() {
    const elem = document.documentElement;
    if (elem.requestFullscreen) {
      elem.requestFullscreen();
    } else if (elem.mozRequestFullScreen) {
      elem.mozRequestFullScreen();
    } else if (elem.webkitRequestFullscreen) {
      elem.webkitRequestFullscreen();
    } else if (elem.msRequestFullscreen) {
      elem.msRequestFullscreen();
    }
  }
  
  // 2. Block common keys
  document.addEventListener('keydown', function (e) {
    const blocked = [
      'F1', 'F5', 'F11', 'F12',
      'Escape',
    ];
    const blockedCombos = (e.ctrlKey || e.altKey || e.metaKey);
  
    if (blocked.includes(e.key) || blockedCombos) {
      e.preventDefault();
      console.log("Blocked key:", e.key);
    }
  });
  
  // 3. Disable right-click
  document.addEventListener('contextmenu', function (e) {
    e.preventDefault();
  });
  
  // 4. Warn if user switches tabs/apps
  window.onblur = function () {
    alert("⚠️ Lockdown active. Please return to the exam environment.");
    // Optional redirect if needed
    // window.location.href = "logout.php";
  };
  
  // 5. Re-enable fullscreen if they exit it
  document.addEventListener("fullscreenchange", function () {
    if (!document.fullscreenElement) {
      enableFullScreen(); // Re-enter fullscreen if they exit it
    }
  });
  
  // 6. Start everything on page load
  window.onload = function () {
    enableFullScreen();
  };
  