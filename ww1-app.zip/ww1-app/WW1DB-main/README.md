# WW1DB
Description of the project:
The client, WW1 Bradford Group, needs a new centralised master Database to access all the information collected over the years. This database is for research at the Bradford Mechanics Library and is for their use only, though it can be accessed by the public. It will be an ever-growing one, with attached Word Documents that provide additional information.  
