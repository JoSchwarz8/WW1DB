package com.example.ww1database;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DataImporter {
    private static final String BIOGRAPHY_CSV = "/biography_information.csv";
    private static final String ROLL_OF_HONOUR_CSV = "/bradford_roll_of_honour.csv";
    private static final String MEMORIALS_CSV = "/bradford_memorials.csv";
    private static final String NEWSPAPERS_CSV = "/newspaper_references.csv";
    private static final String BURIALS_CSV = "/those_buried_in_bradford.csv";

    public static void importData() {
        try (Connection conn = DatabaseConnector.getConnection()) {
            // Import each table in the correct order
            importBradfordRollOfHonour(conn);
            importBiographyInformation(conn);
            importBradfordMemorials(conn);
            importNewspaperReferences(conn);
            importThoseBuriedInBradford(conn);
            System.out.println("✅ All data imported successfully!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void importBradfordRollOfHonour(Connection conn) throws Exception {
        String sql = "INSERT INTO `Bradford and surrounding townships Great War Roll of Honour` (Surname, Forename, `Service no`, Address, `Electoral Ward`, Town, Age, Rank, Regiment, Unit, `Other Regiment`, `Other Unit`, `Other Service no`, Medals, `Enlistment Date`, `Discharge Date`, `Death (in service) Date`, `Misc info (Nroh)`, `Misc info (cwgc)`, `Cemetery/Memorial`, `Cemetery/Memorial Ref`, `Cemetery/Memorial Country`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        importCSV(conn, ROLL_OF_HONOUR_CSV, sql);
    }

    private static void importBiographyInformation(Connection conn) throws Exception {
        String sql = "INSERT INTO `Biography Information` (Surname, Forename, `Service no`, Regiment, Biography) VALUES (?, ?, ?, ?, ?)";
        importCSV(conn, BIOGRAPHY_CSV, sql);
    }

    private static void importBradfordMemorials(Connection conn) throws Exception {
        String sql = "INSERT INTO `Bradford Memorials` (Surname, Forename, `Service no`, Memorial, `Memorial Location`, `Memorial Info`, Postcode, District) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        importCSV(conn, MEMORIALS_CSV, sql);
    }

    private static void importNewspaperReferences(Connection conn) throws Exception {
        String sql = "INSERT INTO `Newspaper References` (Surname, Forename, `Service no`, Rank, Address, Regiment, Unit, `Article Description`, `Newspaper Name`, `Paper Date`, `Page/Column`, `Photo Incl.`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        importCSV(conn, NEWSPAPERS_CSV, sql);
    }

    private static void importThoseBuriedInBradford(Connection conn) throws Exception {
        String sql = "INSERT INTO `Those Buried in Bradford` (Surname, Forename, `Service no`, Age, `Date of Death`, Rank, Regiment, Unit, Cemetery, `Grave Ref`, Info) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        importCSV(conn, BURIALS_CSV, sql);
    }

    private static void importCSV(Connection conn, String filePath, String sql) throws Exception {
        try (BufferedReader br = new BufferedReader(new InputStreamReader(
                DataImporter.class.getResourceAsStream(filePath), StandardCharsets.UTF_8));
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            String line;
            br.readLine(); // Skip header
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                for (int i = 0; i < values.length; i++) {
                    stmt.setString(i + 1, values[i]);
                }
                stmt.executeUpdate();
            }
            System.out.println("✅ Data imported from " + filePath);
        }
    }

    public static void main(String[] args) {
        importData();
    }
}


