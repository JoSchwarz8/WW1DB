package com.example.ww1database;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class DataExporter {
    private static final String BIOGRAPHY_CSV = "src/main/resources/export_biography_information.csv";
    private static final String ROLL_OF_HONOUR_CSV = "src/main/resources/export_bradford_roll_of_honour.csv";
    private static final String MEMORIALS_CSV = "src/main/resources/export_bradford_memorials.csv";
    private static final String NEWSPAPERS_CSV = "src/main/resources/export_newspaper_references.csv";
    private static final String BURIALS_CSV = "src/main/resources/export_those_buried_in_bradford.csv";

    public static void exportData() {
        try (Connection conn = DatabaseConnector.getConnection()) {
            exportTable(conn, "Bradford and surrounding townships Great War Roll of Honour", ROLL_OF_HONOUR_CSV);
            exportTable(conn, "Biography Information", BIOGRAPHY_CSV);
            exportTable(conn, "Bradford Memorials", MEMORIALS_CSV);
            exportTable(conn, "Newspaper References", NEWSPAPERS_CSV);
            exportTable(conn, "Those Buried in Bradford", BURIALS_CSV);
            System.out.println("✅ All data exported successfully!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void exportTable(Connection conn, String tableName, String filePath) throws Exception {
        String sql = "SELECT * FROM `" + tableName + "`";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql);
             FileWriter fw = new FileWriter(filePath)) {

            int columnCount = rs.getMetaData().getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                fw.append(rs.getMetaData().getColumnName(i)).append(",");
            }
            fw.append("\n");

            while (rs.next()) {
                for (int i = 1; i <= columnCount; i++) {
                    fw.append(rs.getString(i)).append(",");
                }
                fw.append("\n");
            }
            System.out.println("✅ Data exported from " + tableName);
        }
    }

    public static void main(String[] args) {
        exportData();
    }
}

