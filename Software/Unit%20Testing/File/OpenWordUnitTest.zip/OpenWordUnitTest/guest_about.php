<?php
/*******************************************************
 * guest_about.php
 *******************************************************/

require_once __DIR__ . '/guest_about_logic.php';

try {
    $content = guestAboutLogic($_GET);

    header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
    header('Content-Disposition: inline; filename="' . basename($_GET['doc']) . '"');

    echo $content;
} catch (\RuntimeException $e) {
    echo $e->getMessage();
}
