<?php
/*******************************************************
 * open_about_logic.php
 *
 * A function openAboutLogic() that checks a doc param,
 * ensures file existence, or throws an exception.
 *******************************************************/

function openAboutLogic(array $get): string
{
    $validDocs = [
        'BradSurrTowns.docx',
        'BradMem.docx',
        'BurBrad.docx',
        'NewsRefs.docx',
        'Bios.docx'
    ];

    // Check doc param
    if (empty($get['doc']) || !in_array($get['doc'], $validDocs)) {
        throw new \RuntimeException("Invalid or missing doc parameter.");
    }

    $filePath = __DIR__ . '/' . $get['doc'];
    if (!file_exists($filePath)) {
        throw new \RuntimeException("File not found on server: {$get['doc']}");
    }

    // Return file contents (instead of readfile)
    return file_get_contents($filePath);
}
