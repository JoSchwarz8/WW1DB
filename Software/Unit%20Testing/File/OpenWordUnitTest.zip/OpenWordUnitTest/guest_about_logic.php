<?php
/*******************************************************
 * guest_about_logic.php
 *
 * A function guestAboutLogic() that does the same checks
 * for guest mode, also throwing exceptions if invalid.
 *******************************************************/

function guestAboutLogic(array $get): string
{
    $validDocs = [
        'BradSurrTowns.docx',
        'BradMem.docx',
        'BurBrad.docx',
        'NewsRefs.docx',
        'Bios.docx'
    ];

    if (empty($get['doc']) || !in_array($get['doc'], $validDocs)) {
        throw new \RuntimeException("Invalid or missing doc parameter.");
    }

    $filePath = __DIR__ . '/' . $get['doc'];
    if (!file_exists($filePath)) {
        throw new \RuntimeException("File not found on server: {$get['doc']}");
    }

    // Return the file contents
    return file_get_contents($filePath);
}
