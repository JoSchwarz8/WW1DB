<?php
use PHPUnit\Framework\TestCase;

/**
 * Tests for guest_about_logic.php
 */
require_once __DIR__ . '/../guest_about_logic.php';

class GuestAboutTest extends TestCase
{
    public function testNoDocParameter()
    {
        $this->expectException(\RuntimeException::class);
        $this->expectExceptionMessage('Invalid or missing doc parameter.');

        guestAboutLogic([]);
    }

    public function testInvalidDoc()
    {
        $this->expectException(\RuntimeException::class);
        $this->expectExceptionMessage('Invalid or missing doc parameter.');

        guestAboutLogic(['doc' => 'Unknown.docx']);
    }

    public function testDocInListButMissingFile()
    {
        $this->expectException(\RuntimeException::class);
        $this->expectExceptionMessage('File not found on server: Bios.docx');

        guestAboutLogic(['doc' => 'Bios.docx']);
    }

    public function testDocFileOk()
    {
        file_put_contents(__DIR__ . '/../Bios.docx', 'Guest doc content');

        $content = guestAboutLogic(['doc' => 'Bios.docx']);
        $this->assertStringContainsString('Guest doc content', $content);

        unlink(__DIR__ . '/../Bios.docx');
    }
}
