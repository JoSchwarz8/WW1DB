<?php
use PHPUnit\Framework\TestCase;

/**
 * Tests for open_about_logic.php
 */
require_once __DIR__ . '/../open_about_logic.php';

class OpenAboutTest extends TestCase
{
    public function testNoDocParameter()
    {
        // Expect an exception about invalid doc param
        $this->expectException(\RuntimeException::class);
        $this->expectExceptionMessage('Invalid or missing doc parameter.');

        // No doc => triggers error
        openAboutLogic([]);
    }

    public function testInvalidDocNotInList()
    {
        $this->expectException(\RuntimeException::class);
        $this->expectExceptionMessage('Invalid or missing doc parameter.');

        openAboutLogic(['doc' => 'Unknown.docx']);
    }

    public function testDocInListButMissingFile()
    {
        $this->expectException(\RuntimeException::class);
        $this->expectExceptionMessage('File not found on server: BradSurrTowns.docx');

        openAboutLogic(['doc' => 'BradSurrTowns.docx']);
    }

    public function testDocFileFoundSuccess()
    {
        // Create dummy doc so file_exists passes
        file_put_contents(__DIR__ . '/../BradSurrTowns.docx', 'Dummy content');

        // Should succeed => no exception
        $content = openAboutLogic(['doc' => 'BradSurrTowns.docx']);
        $this->assertStringContainsString('Dummy content', $content);

        // Cleanup
        unlink(__DIR__ . '/../BradSurrTowns.docx');
    }
}
