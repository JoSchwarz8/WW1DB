<?php
/*******************************************************
 * open_about.php
 *
 * Minimal script that calls openAboutLogic($_GET),
 * sets headers, and echoes file content, or prints
 * the exception message on error.
 *******************************************************/

require_once __DIR__ . '/open_about_logic.php';

try {
    $content = openAboutLogic($_GET);

    header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
    header('Content-Disposition: inline; filename="' . basename($_GET['doc']) . '"');

    echo $content;
} catch (\RuntimeException $e) {
    echo $e->getMessage();
}
