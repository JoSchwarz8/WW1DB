<?php

// 1. Define allowed PDF filenames
$validDocs = [
    'BradSurrTowns.pdf',
    'BradMem.pdf',
    'BurBrad.pdf',
    'NewsRefs.pdf',
    'Bios.pdf'
];

// 2. Get parameters from the URL
$doc  = isset($_GET['doc'])  ? $_GET['doc']  : '';
$mode = isset($_GET['mode']) ? $_GET['mode'] : 'guest'; // default to guest

// 3. Check if doc is valid
if (!in_array($doc, $validDocs)) {
    die("Invalid or missing doc parameter.");
}

// 4. Build full path to the PDF
$filePath = __DIR__ . '/' . $doc; // same directory as this script
if (!file_exists($filePath)) {
    die("File not found on the server: $doc");
}

// 5. Depending on admin vs. guest, you can do some server-side logic.
//    (In reality, the PDF is the same file; we can't truly "lock" it read-only.)
//    We'll just set a custom header or message to differentiate.
if ($mode === 'admin') {
    // In a perfect world, you'd have WebDAV or some mechanism for saving
    // changes. This just labels it as "admin".
    $xPdfMode = 'Admin: Potentially editable (locally).';
} else {
    $xPdfMode = 'Guest: View only.';
}

// 6. Output the PDF inline
//    This suggests the browser should open it in a viewer
//    (often in a new tab), not download it.
header('Content-Type: application/pdf');
header('Content-Disposition: inline; filename="' . basename($doc) . '"');
header('Content-Transfer-Encoding: binary');
header('Accept-Ranges: bytes');

// Optional custom header so you can confirm mode in logs
header("X-Mode: $xPdfMode");

// 7. Stream the PDF file
readfile($filePath);
exit;
