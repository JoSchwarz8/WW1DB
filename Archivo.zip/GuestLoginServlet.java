package com.example.lockdownfeature.demo.WW1;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/GuestLoginServlet")
public class GuestLoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String username = request.getParameter("guestusername");
        String password = request.getParameter("guestpassword");

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM user_details WHERE \"User Type\" = ? AND password = ?";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, "Guest");
            statement.setString(2, password);

            ResultSet rs = statement.executeQuery();

            response.setContentType("text/html");
            PrintWriter out = response.getWriter();

            if (rs.next()) {
                out.println("<h3>Login Successful! Welcome, " + username + ".</h3>");
                response.sendRedirect("dashboard.html");
            } else {
                out.println("<h3>Login Failed. Invalid username or password.</h3>");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}


